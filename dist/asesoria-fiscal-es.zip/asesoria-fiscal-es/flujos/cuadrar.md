# Cuadra los modelos de un cliente entre sí y contra la contabilidad

> Procedimiento. En claude.ai se activa pidiendolo con palabras: «cliente> <ejercicio».



Antes de responder:

- Genera la plantilla: `python3 scripts/cuadrar.py --plantilla`
- Rellénala con las cifras del cliente que tengas
- Ejecuta `cuadrar.py --datos <fichero>` y resuelve cada descuadre
- Distingue lo que cuadra de lo que no se ha podido comprobar
