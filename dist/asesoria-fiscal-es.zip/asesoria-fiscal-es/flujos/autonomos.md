# Fiscalidad del autónomo: alta, gastos deducibles, módulos y autónomo vs. sociedad

> Procedimiento. En claude.ai se activa pidiendolo con palabras: «la duda o el cliente».



Carga la skill `autonomos-y-modulos` y trabaja con ella.

Antes de responder:

- Régimen de IRPF y de IVA aplicable
- Si es un gasto: correlación, afectación, factura completa y registro
- Vehículo y suministros: reglas distintas en IRPF y en IVA
- Si es autónomo vs. sociedad: tabla numérica a tres escenarios

Consulta las cifras con `python3 scripts/parametros.py buscar <ámbito>`,
nunca de memoria. Lo que salga `volatil` o `sin_verificar` va marcado como tal en el
entregable.

Si falta un dato que cambia la respuesta —ejercicio, CCAA, régimen del contribuyente—
pregúntalo antes de calcular.
