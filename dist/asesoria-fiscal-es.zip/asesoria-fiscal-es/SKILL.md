---
name: asesoria-fiscal-es
description: Asesoría fiscal española para despacho profesional. IRPF, IVA, Sociedades, retenciones, informativas, Intrastat, procedimientos con la AEAT, control de cartera y generación de ficheros en el diseño de registro oficial. Úsala para cualquier consulta fiscal española, cálculo o revisión de impuestos, notificación de Hacienda o gestión de la cartera de clientes.
license: MIT
---

# Asesoría fiscal española

Conocimiento y herramientas para el trabajo diario de un despacho fiscal en España.
Todas las rutas de este documento son **relativas a la carpeta de esta skill**.

## Cómo usar esta skill

1. **Lee siempre primero** `referencias/marco-fiscal-espanol.md`. Son las reglas de
   trabajo: jerarquía de fuentes, prohibición de inventar cifras y formato de los
   entregables. Se aplican por encima de todo lo demás.
2. Localiza la materia en las tablas de abajo y **lee solo el fichero que necesites**.
   No cargues todas las referencias: son unas 300 KB.
3. Si la tarea encaja con un flujo de trabajo, sigue el de `flujos/`.
4. Antes de dar por bueno un entregable, aplica `revision/revisor-fiscal.md`.

## Las tres reglas que no se saltan

**No memorices cifras: consúltalas.**
```bash
python3 scripts/parametros.py buscar iva
python3 scripts/parametros.py ver is.tipo.microempresa
python3 scripts/parametros.py revisar     # qué NO es fiable
```
Lo que salga `volatil` o `sin_verificar` **no se usa en un entregable sin contrastarlo**.
Escribe `⚠️ SIN VERIFICAR — contrastar en <fuente>` junto al dato.

**No inventes referencias.** Cita el artículo concreto. Si no estás seguro del número de
una consulta de la DGT o del ECLI de una sentencia, describe el criterio sin numerarlo.

**Nada se presenta ante la AEAT.** Esta skill prepara, calcula y cuadra. Presentar es un
acto humano con certificado. Nunca digas que una declaración «se ha presentado».

## Materias

| Fichero | Contenido |
|---|---|
| `referencias/marco-fiscal-espanol.md` | Reglas de trabajo del despacho |
| `referencias/catalogo-modelos-aeat.md` | Qué modelo hay que presentar. Catálogo de todos los modelos de la AEAT |
| `referencias/calendario-fiscal.md` | Calendario fiscal del despacho |
| `referencias/control-de-cartera.md` | Control de cartera sobre el Control.xlsx |
| `referencias/documentacion-de-clientes.md` | Documentación que envían los clientes por sus cuatro canales |
| `referencias/sage-despachos.md` | Sage Despachos |
| `referencias/gestion-de-despacho.md` | Gestión interna del despacho |
| `referencias/generacion-de-ficheros.md` | Generar ficheros de declaraciones en el diseño de registro oficial de  |
| `referencias/iva.md` | IVA |
| `referencias/irpf.md` | IRPF |
| `referencias/impuesto-sociedades.md` | Impuesto sobre Sociedades |
| `referencias/retenciones-y-censos.md` | Retenciones e ingresos a cuenta y obligaciones censales |
| `referencias/autonomos-y-modulos.md` | Fiscalidad del autónomo |
| `referencias/informativas-y-facturacion.md` | Declaraciones informativas y obligaciones de facturación |
| `referencias/patrimonio-sucesiones-y-no-residentes.md` | Tributos patrimoniales y no residentes |
| `referencias/procedimientos-tributarios.md` | Procedimientos frente a Hacienda |
| `referencias/intrastat.md` | Intrastat |

## Modelos concretos

| Fichero | Contenido |
|---|---|
| `referencias/modelo-036-037.md` | Modelo 036 y 037, declaración censal |
| `referencias/modelo-100.md` | Modelo 100, declaración anual del IRPF |
| `referencias/modelo-111.md` | Modelo 111, retenciones del trabajo y de actividades económicas |
| `referencias/modelo-115-180.md` | Modelos 115 y 180, retenciones por alquiler de local |
| `referencias/modelo-123-193.md` | Modelos 123 y 193, retenciones de dividendos e intereses |
| `referencias/modelo-130-131.md` | Modelos 130 y 131, pagos fraccionados del IRPF |
| `referencias/modelo-190.md` | Modelo 190, resumen anual de retenciones |
| `referencias/modelo-200.md` | Modelo 200, declaración anual del Impuesto sobre Sociedades |
| `referencias/modelo-202.md` | Modelo 202, pago fraccionado del Impuesto sobre Sociedades |
| `referencias/modelo-210.md` | Modelo 210, IRNR de no residentes sin establecimiento permanente |
| `referencias/modelo-232.md` | Modelo 232, operaciones vinculadas |
| `referencias/modelo-303.md` | Modelo 303, autoliquidación del IVA |
| `referencias/modelo-347.md` | Modelo 347, operaciones con terceros |
| `referencias/modelo-349.md` | Modelo 349, operaciones intracomunitarias |
| `referencias/modelo-390.md` | Modelo 390, resumen anual del IVA |
| `referencias/modelo-714-718.md` | Modelos 714 y 718, Patrimonio y Grandes Fortunas |
| `referencias/modelo-720-721.md` | Modelos 720 y 721, bienes y criptomonedas en el extranjero |

Para un modelo sin fichero propio, usa `referencias/catalogo-modelos-aeat.md`.

## Flujos de trabajo

| Fichero | Para qué |
|---|---|
| `flujos/alta-cliente.md` | Onboarding completo de un cliente nuevo, con diagnóstico y calendario |
| `flujos/autonomos.md` | Fiscalidad del autónomo |
| `flujos/calendario.md` | Muestra las obligaciones y plazos pendientes, o construye el calendari |
| `flujos/campana-renta.md` | Prepara o revisa una declaración de IRPF de campaña de Renta |
| `flujos/cartera.md` | Estado de la cartera — qué está pendiente, qué vence, qué hay que revi |
| `flujos/cierre-fiscal.md` | Cierre contable y fiscal del ejercicio con los ajustes del Impuesto so |
| `flujos/cierre-trimestre.md` | Ejecuta el cierre trimestral completo de un cliente y prepara todos su |
| `flujos/consulta-fiscal.md` | Resuelve una consulta fiscal con análisis normativo y nota para el exp |
| `flujos/cuadrar.md` | Cuadra los modelos de un cliente entre sí y contra la contabilidad |
| `flujos/despacho.md` | Gestión del despacho |
| `flujos/documentacion.md` | Documentación de clientes |
| `flujos/generar-fichero.md` | Genera el fichero de una declaración listo para importar en la sede de |
| `flujos/informativas.md` | Declaraciones informativas y facturación |
| `flujos/intrastat.md` | Prepara y genera la declaración Intrastat de un periodo |
| `flujos/irpf.md` | Consulta de IRPF |
| `flujos/iva.md` | Consulta de IVA |
| `flujos/modelo.md` | Prepara, revisa o genera cualquier modelo tributario español |
| `flujos/patrimonio.md` | Patrimonio, herencias, donaciones, transmisiones y no residentes |
| `flujos/privacidad.md` | Comprueba que no se filtran datos de clientes al repositorio |
| `flujos/procedimientos.md` | Procedimientos con Hacienda |
| `flujos/requerimiento.md` | Analiza una notificación de Hacienda y prepara la contestación |
| `flujos/retenciones.md` | Retenciones e ingresos a cuenta |
| `flujos/sage.md` | Sage Despachos |
| `flujos/sociedades.md` | Consulta del Impuesto sobre Sociedades |
| `flujos/verificar-diseno.md` | Contrasta el diseño de registro de un modelo con la orden oficial y lo |
| `flujos/verificar-normativa.md` | Verifica en fuente oficial los parámetros fiscales y actualiza el fich |

## Revisión y redacción

| Fichero | Para qué |
|---|---|
| `revision/redactor-fiscal.md` | Redactor de escritos y comunicaciones fiscales |
| `revision/revisor-fiscal.md` | Revisor independiente de trabajos fiscales |

## Herramientas

Todas funcionan con la biblioteca estándar de Python 3.10+, salvo donde se indica.

| Script | Para qué |
|---|---|
| `scripts/parametros.py` | Tipos, umbrales y límites, con su estado de fiabilidad |
| `scripts/calcular_plazos.py` | Vencimientos, periodo voluntario, recargos de los arts. 27 y 28 LGT |
| `scripts/cuadrar.py` | Cuadrar modelos entre sí y contra la contabilidad |
| `scripts/lib/validaciones.py` | Validar NIF, NIE, CIF, NIF-IVA, IBAN, código NC8 |
| `scripts/generar_informativa.py` | Fichero de una informativa en diseño de registro |
| `scripts/generar_intrastat.py` | Fichero Intrastat para el portal de Aduanas |
| `scripts/validar_fichero.py` | Validar y descomponer un fichero generado |
| `scripts/control.py` | Control de cartera sobre un Control.xlsx — **necesita `openpyxl`** |

Empieza cualquier script por `--help`: todos lo tienen y explican su entrada.

## Antes de responder

Determina, y pregunta si falta algo que cambie el resultado:

- **Ejercicio fiscal**: la respuesta cambia cada año.
- **Territorio**: común, foral (Álava, Bizkaia, Gipuzkoa, Navarra), Canarias (IGIC) o
  Ceuta y Melilla (IPSI). En territorio foral la normativa estatal **no** aplica: avisa
  y detente.
- **CCAA** si hay IRPF, ISD, ITP o Patrimonio de por medio.
- **Régimen del contribuyente** y cifra de negocios del año anterior.

## Método

```
HECHOS → CALIFICACIÓN → SUJECIÓN → DEVENGO → BASE → TIPO Y CUOTA
      → OBLIGACIONES (modelo, plazo, forma) → RIESGO → RECOMENDACIÓN
```

Ante una posición discutible, cuantifica: cuota + recargo o sanción + intereses =
exposición total, y la probabilidad de comprobación con su motivo.

## Datos de clientes

Alta sensibilidad económica. No los reproduzcas fuera de su contexto y anonimiza en
plantillas y ejemplos. Los despachos son sujetos obligados de la Ley 10/2010: ante
indicios de operativa sospechosa, señálalo al responsable de cumplimiento en lugar de
tratarlo como un problema técnico.
