---
name: asesoria-fiscal-es
description: Asesoría fiscal española para despacho profesional. IRPF, IVA, Sociedades, retenciones, informativas, Intrastat, procedimientos con la AEAT, control de cartera y generación de ficheros en el diseño de registro oficial. Úsala para cualquier consulta fiscal española, cálculo o revisión de impuestos, notificación de Hacienda o gestión de la cartera de clientes.
license: MIT
---

# Asesoría fiscal española

Conocimiento y herramientas para el trabajo diario de un despacho fiscal en España.
Todas las rutas de este documento son **relativas a la carpeta de esta skill**.

## Cómo usar esta skill

1. **Lee siempre primero** `referencias/asesoria-fiscal.md`. Son las reglas de
   trabajo: jerarquía de fuentes, prohibición de inventar cifras y formato de los
   entregables. Se aplican por encima de todo lo demás.
2. Localiza la materia en las tablas de abajo y **lee solo el fichero que necesites**.
   No cargues todas las referencias: son unas 300 KB.
3. Si la tarea encaja con un flujo de trabajo, sigue el de `flujos/`.
4. Antes de dar por bueno un entregable, aplica `revision/revisor-fiscal.md`.

## Las tres reglas que no se saltan

**No memorices cifras: consúltalas.**
```bash
python3 scripts/parametros.py buscar iva
python3 scripts/parametros.py ver is.tipo.microempresa
python3 scripts/parametros.py revisar     # qué NO es fiable
```
Lo que salga `volatil` o `sin_verificar` **no se usa en un entregable sin contrastarlo**.
Escribe `⚠️ SIN VERIFICAR — contrastar en <fuente>` junto al dato.

**No inventes referencias.** Cita el artículo concreto. Si no estás seguro del número de
una consulta de la DGT o del ECLI de una sentencia, describe el criterio sin numerarlo.

**Nada se presenta ante la AEAT.** Esta skill prepara, calcula y cuadra. Presentar es un
acto humano con certificado. Nunca digas que una declaración «se ha presentado».

## Materias

Cada materia tiene su fichero, y las más extensas una subcarpeta con el detalle. Lee
solo lo que necesites: el conjunto son unas 300 KB.

| Fichero | Contenido |
|---|---|
| `referencias/asesoria-fiscal.md` | Asesoría fiscal española |
| `referencias/consultas-por-impuesto.md` | Resolver dudas fiscales por impuesto |
| `referencias/modelos-aeat.md` | Modelos de la AEAT |
| `referencias/control-de-cartera.md` | Control de cartera sobre el Control.xlsx |
| `referencias/entrada-de-documentos.md` | Procesar lo que mandan los clientes |
| `referencias/generacion-de-entregables.md` | Producir los entregables del despacho |
| `referencias/procedimientos-y-plazos.md` | Actuaciones con Hacienda y cómputo de plazos |
| `referencias/gestion-del-despacho.md` | Gestión interna del despacho |

`referencias/consultas-por-impuesto/` tiene un fichero por impuesto, y
`referencias/modelos-aeat/` uno por modelo.

## Flujos de trabajo

| Fichero | Para qué |
|---|---|
| `flujos/cartera.md` | Estado de la cartera |
| `flujos/cierre.md` | Cierre trimestral, cierre del ejercicio o campaña de Renta |
| `flujos/cliente.md` | Alta de cliente, ficha, calendario de obligaciones y encargo |
| `flujos/consulta.md` | Resuelve una duda fiscal con la norma que la sostiene |
| `flujos/documentos.md` | Procesa lo que manda un cliente |
| `flujos/entregable.md` | Genera un fichero, un Excel, un informe o un escrito |
| `flujos/modelo.md` | Prepara, revisa o cuadra cualquier modelo tributario |
| `flujos/requerimiento.md` | Analiza una notificación de Hacienda y prepara la contestación |
| `flujos/verificar.md` | Contrasta normativa, diseños de registro y privacidad |

## Revisión y redacción

| Fichero | Para qué |
|---|---|
| `revision/redactor-fiscal.md` | Redactor de escritos y comunicaciones fiscales |
| `revision/revisor-fiscal.md` | Revisor independiente de trabajos fiscales |

## Herramientas

Todas funcionan con la biblioteca estándar de Python 3.10+, salvo donde se indica.

| Script | Para qué |
|---|---|
| `scripts/parametros.py` | Tipos, umbrales y límites, con su estado de fiabilidad |
| `scripts/calcular_plazos.py` | Vencimientos, periodo voluntario, recargos de los arts. 27 y 28 LGT |
| `scripts/cuadrar.py` | Cuadrar modelos entre sí y contra la contabilidad |
| `scripts/lib/validaciones.py` | Validar NIF, NIE, CIF, NIF-IVA, IBAN, código NC8 |
| `scripts/generar_informativa.py` | Fichero de una informativa en diseño de registro |
| `scripts/generar_intrastat.py` | Fichero Intrastat para el portal de Aduanas |
| `scripts/validar_fichero.py` | Validar y descomponer un fichero generado |
| `scripts/control.py` | Control de cartera sobre un Control.xlsx — **necesita `openpyxl`** |

Empieza cualquier script por `--help`: todos lo tienen y explican su entrada.

## Antes de responder

Determina, y pregunta si falta algo que cambie el resultado:

- **Ejercicio fiscal**: la respuesta cambia cada año.
- **Territorio**: común, foral (Álava, Bizkaia, Gipuzkoa, Navarra), Canarias (IGIC) o
  Ceuta y Melilla (IPSI). En territorio foral la normativa estatal **no** aplica: avisa
  y detente.
- **CCAA** si hay IRPF, ISD, ITP o Patrimonio de por medio.
- **Régimen del contribuyente** y cifra de negocios del año anterior.

## Método

```
HECHOS → CALIFICACIÓN → SUJECIÓN → DEVENGO → BASE → TIPO Y CUOTA
      → OBLIGACIONES (modelo, plazo, forma) → RIESGO → RECOMENDACIÓN
```

Ante una posición discutible, cuantifica: cuota + recargo o sanción + intereses =
exposición total, y la probabilidad de comprobación con su motivo.

## Datos de clientes

Alta sensibilidad económica. No los reproduzcas fuera de su contexto y anonimiza en
plantillas y ejemplos. Los despachos son sujetos obligados de la Ley 10/2010: ante
indicios de operativa sospechosa, señálalo al responsable de cumplimiento en lugar de
tratarlo como un problema técnico.
